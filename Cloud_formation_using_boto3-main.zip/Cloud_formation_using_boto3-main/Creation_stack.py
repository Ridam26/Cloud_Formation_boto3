import boto3
import yaml
file = open('CloudFormation.yaml','r' )
content = file.read()
print(type(content))
print(content)
client = boto3.client('cloudformation')

response = client.create_stack(
    StackName='My-demo-test-python',
    TemplateBody='content',
    TemplateURL='string',
    # Parameters=[
    #     {
    #         'ParameterKey': 'string',
    #         'ParameterValue': 'string',
    #         'UsePreviousValue': True|False,
    #         'ResolvedValue': 'string'
    #     },
    # ],
    # DisableRollback=True|False,
    # RollbackConfiguration={
    #     'RollbackTriggers': [
    #         {
    #             'Arn': 'string',
    #             'Type': 'string'
    #         },
    #     ],
    #     'MonitoringTimeInMinutes': 123
    # },
    # TimeoutInMinutes=123,
    # NotificationARNs=[
    #     'string',
    # ],
    # Capabilities=[
    #     'CAPABILITY_IAM'|'CAPABILITY_NAMED_IAM'|'CAPABILITY_AUTO_EXPAND',
    # ],
    # ResourceTypes=[
    #     'string',
    # ],
    # RoleARN='string',
    # OnFailure='DO_NOTHING'|'ROLLBACK'|'DELETE',
    # StackPolicyBody='string',
    # StackPolicyURL='string',
    # Tags=[
    #     {
    #         'Key': 'string',
    #         'Value': 'string'
    #     },
    # ],
    # ClientRequestToken='string',
    # EnableTerminationProtection=True|False
)
print(response)


